# MDIA 1620

## Group Members
- Trevor Tan
- Jonathan Santiaguel
